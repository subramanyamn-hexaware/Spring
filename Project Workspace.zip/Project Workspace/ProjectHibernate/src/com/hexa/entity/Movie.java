package com.hexa.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MOVIE")
public class Movie {

	@Id
	@Column(name = "MOV_ID", insertable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int movId;

	@Column(name = "MOV_NAME")
	private String movName;

	@Column(name = "MOV_DESC")
	private String movDesc;

	@Column(name = "MOV_CAST")
	private String movCast;
	
	@Column(name = "MOV_IMAGE")
	private String movImage;

	@Column(name = "RELEASE_DATE")
	private Date releaseDate;

	@Column(name = "TOTAL_SEATS")
	private int totalSeats;

	@OneToMany(mappedBy = "movieBooked")
	private Set<BookingDetails> bookDetails;

	@OneToMany(mappedBy = "movieScheduled")
	private Set<MovieSchedule> moviesScheduled;

	public int getMovId() {
		return movId;
	}

	public void setMovId(int movId) {
		this.movId = movId;
	}

	public String getMovName() {
		return movName;
	}

	public void setMovName(String movName) {
		this.movName = movName;
	}

	public String getMovDesc() {
		return movDesc;
	}

	public void setMovDesc(String movDesc) {
		this.movDesc = movDesc;
	}

	public String getMovCast() {
		return movCast;
	}

	public void setMovCast(String movCast) {
		this.movCast = movCast;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public Set<BookingDetails> getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(Set<BookingDetails> bookDetails) {
		this.bookDetails = bookDetails;
	}

	public Set<MovieSchedule> getMoviesScheduled() {
		return moviesScheduled;
	}

	public void setMoviesScheduled(Set<MovieSchedule> moviesScheduled) {
		this.moviesScheduled = moviesScheduled;
	}

	public String getMovImage() {
		return movImage;
	}

	public void setMovImage(String movImage) {
		this.movImage = movImage;
	}

	
}

package com.hexa.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MOVIE_SCHEDULE")
public class MovieSchedule {

	@Id
	@Column(name = "SCH_ID", insertable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int schId;

	@Column(name = "SCH_DATE")
	private Date schDate;

	@Column(name = "SCH_SHOW")
	private String schShow;

	@Column(name = "SCH_SEATS")
	private int schSeats;

	@ManyToOne
	@JoinColumn(name = "M_ID", referencedColumnName = "MOV_ID")
	private Movie movieScheduled;

	@OneToMany(mappedBy = "scheduledMovie")
	private Set<BookingDetails> bookingSchedules;

	public int getSchId() {
		return schId;
	}

	public void setSchId(int schId) {
		this.schId = schId;
	}

	public Date getSchDate() {
		return schDate;
	}

	public void setSchDate(Date schDate) {
		this.schDate = schDate;
	}

	public String getSchShow() {
		return schShow;
	}

	public void setSchShow(String schShow) {
		this.schShow = schShow;
	}

	public int getSchSeats() {
		return schSeats;
	}

	public void setSchSeats(int schSeats) {
		this.schSeats = schSeats;
	}

	public Movie getMovieScheduled() {
		return movieScheduled;
	}

	public void setMovieScheduled(Movie movieScheduled) {
		this.movieScheduled = movieScheduled;
	}

	public Set<BookingDetails> getBookingSchedules() {
		return bookingSchedules;
	}

	public void setBookingSchedules(Set<BookingDetails> bookingSchedules) {
		this.bookingSchedules = bookingSchedules;
	}

}

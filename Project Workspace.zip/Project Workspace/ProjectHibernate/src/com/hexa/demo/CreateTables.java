package com.hexa.demo;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.Movie;
import com.hexa.entity.SeatInfo;

public class CreateTables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Configuration cfg = new AnnotationConfiguration().configure();
//		SessionFactory sfac = cfg.buildSessionFactory();
//		System.out.println("Tables Created ..");
		MDao dao = new MDaoImpl();
		Movie m = dao.getMovieDetails(2);
		System.out.println(m.getMovId() + " " + m.getMovCast() + " " + m.getMovDesc() +  " " +m.getMovName() + " " + m.getTotalSeats());
	
		List<SeatInfo> s = dao.getSeats(1);
		for(SeatInfo ss: s) {
			System.out.println(ss.getSeatNo());
		}
		
	}

}

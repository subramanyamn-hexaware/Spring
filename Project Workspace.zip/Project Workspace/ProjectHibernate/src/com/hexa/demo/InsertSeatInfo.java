package com.hexa.demo;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.BookingDetails;
import com.hexa.entity.SeatInfo;

public class InsertSeatInfo {

	public static void main(String[] args) {
	MDao dao = new MDaoImpl();
	SeatInfo si = new SeatInfo();
	BookingDetails bd = new BookingDetails();
	bd.setBookId(4);
	//si.setsNo(1);
	si.setSeatNo(4);
	si.setBookingDetails(bd);
	dao.insertSeatInfo(si);
	

	}

}

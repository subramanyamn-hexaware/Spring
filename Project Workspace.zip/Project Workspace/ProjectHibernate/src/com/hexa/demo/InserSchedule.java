package com.hexa.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;

public class InserSchedule {

	public static void main(String[] args) throws ParseException {
	MDao dao = new MDaoImpl();
	  String sDate1="31-12-2017";  
	    Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(sDate1);  
	MovieSchedule ms = new MovieSchedule();
	Movie m = new Movie();
	m.setMovId(1);
	
	ms.setSchId(1);
	ms.setSchShow("MATNEE");
	ms.setSchDate(date1);
	ms.setSchSeats(36);
	ms.setMovieScheduled(m);
	int i =dao.insertSchedule(ms);
	if(i>0) {
		System.out.println("row inserted");
	}
	else {
		System.out.println("error in insertin row");
	}
	}

}

package com.hexa.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.BookingDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

public class getScheduledDetails {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = "2018-04-04";
		MDao dao = new MDaoImpl();
		Movie mv = new Movie();
		mv.setMovId(5);
		MovieSchedule ms = new MovieSchedule();
		ms.setMovieScheduled(mv);
		ms.setSchDate(sdf.parse(date));
		ms.setSchShow("MATNEE");
		
		MovieSchedule s = dao.getScheduleDetails(ms);
		System.out.println(s.getSchId() + " " + s.getSchSeats() + " " + s.getSchShow());
	
		
		
	}

}

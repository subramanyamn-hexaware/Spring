package com.hexa.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.BookingDetails;
import com.hexa.entity.CustomerDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;

public class InsertBookingDetails {

	public static void main(String[] args) throws ParseException {
		MDao dao = new MDaoImpl();
		 String sDate1="04-04-2018";  
		    Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(sDate1);  
		BookingDetails bd = new BookingDetails();
		CustomerDetails cd = new CustomerDetails();
		Movie m =new Movie();
		MovieSchedule ms = new MovieSchedule();
		ms.setSchId(1);
		m.setMovId(1);
		cd.setCustId(1);
		//bd.setBookId(1);
		bd.setNoOfTckts(1);
		bd.setTotalPrice(120);
		bd.setBookDate(date1);
		bd.setCustDetails(cd);
		bd.setMovieBooked(m);
		bd.setScheduledMovie(ms);
		dao.insertBookingInfo(bd);
	}

}

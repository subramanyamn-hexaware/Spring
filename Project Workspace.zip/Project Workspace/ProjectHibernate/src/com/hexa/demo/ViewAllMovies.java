package com.hexa.demo;

import java.util.List;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.Movie;

public class ViewAllMovies {

	public static void main(String[] args) {
MDao dao = new MDaoImpl();
List<Movie> lst = dao.getMovies();
for(Movie mov : lst) {
	System.out.println(mov.getMovId()+ " "+mov.getMovName()+" "+mov.getMovDesc()+" "
			+mov.getMovCast()+" "+mov.getTotalSeats()+" "+mov.getReleaseDate());
}

	}

}

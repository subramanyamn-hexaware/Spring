package com.hexa.service;

import java.util.List;

import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

public interface BookingService {
	public List<Integer> getBookedSeatsInfo(MovieSchedule ms);
}

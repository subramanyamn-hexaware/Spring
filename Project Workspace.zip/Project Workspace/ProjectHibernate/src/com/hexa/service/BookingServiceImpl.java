package com.hexa.service;

import java.util.ArrayList;
import java.util.List;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;


public class BookingServiceImpl implements BookingService{

	MDao dao;
	
	@Override
	public List<Integer> getBookedSeatsInfo(MovieSchedule ms) {
		int scheduleId;
		List<SeatInfo> seatDetails;
		List<Integer> seats = new ArrayList<>();
		dao = new MDaoImpl();
		MovieSchedule scheduleDetails =  dao.getScheduleDetails(ms);
		if(scheduleDetails != null) {
			scheduleId = scheduleDetails.getSchId();
			seatDetails = dao.getSeats(scheduleId);
			for(SeatInfo sinfo : seatDetails) {
				seats.add(sinfo.getSeatNo());
			}
		}
		return seats;
	}

}

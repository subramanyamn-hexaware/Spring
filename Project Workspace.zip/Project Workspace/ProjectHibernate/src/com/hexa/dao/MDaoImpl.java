package com.hexa.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.hexa.entity.BookingDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

public class MDaoImpl implements MDao {

	private static SessionFactory sfac;

	static {
		Configuration cfg = new AnnotationConfiguration().configure();
		sfac = cfg.buildSessionFactory();
	}

	@Override
	public Movie getMovieDetails(int mid) {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie where movId = ?");
		qry.setInteger(0, mid);
		Movie movieDetails = (Movie) qry.uniqueResult();
		return movieDetails;
	}

	@Override
	public List<SeatInfo> getSeats(int scheduleId) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from SeatInfo s inner join fetch  s.bookingDetails b where b.scheduledMovie.schId = ?  ");
		qry.setInteger(0, scheduleId);
		List<SeatInfo> s = qry.list();
		return s;
	}

	@Override
	public MovieSchedule getScheduleDetails(MovieSchedule ms) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from MovieSchedule where movieScheduled.movId = ? and schShow = ? and  schDate = ?");
		qry.setInteger(0, ms.getMovieScheduled().getMovId());
		qry.setString(1,ms.getSchShow());
		qry.setDate(2, ms.getSchDate());
		MovieSchedule s = (MovieSchedule) qry.uniqueResult();
		return s;
	}

	@Override
	public List<Movie> getMovies() {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie m");
		List<Movie> lst = qry.list();
		sess.close();
		return lst;
	}

	@Override
	public int insertSchedule(MovieSchedule ms) {
		Session sess = sfac.openSession();
		Transaction tx = sess.beginTransaction();
		sess.save(ms);
		tx.commit();
		sess.close();
		return 1;
	}

	@Override
	public int insertBookingInfo(BookingDetails bd) {
		Session sess = sfac.openSession();
		Transaction tx = sess.beginTransaction();
		sess.save(bd);
		tx.commit();
		sess.close();
		return 1;
	}

	@Override
	public int insertSeatInfo(SeatInfo si) {
		Session sess = sfac.openSession();
		Transaction tx = sess.beginTransaction();
		sess.save(si);
		tx.commit();
		sess.close();
		return 1;
	}

}

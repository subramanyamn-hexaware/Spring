package com.hexa.dao;

import java.util.Date;
import java.util.List;

import com.hexa.entity.BookingDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;


public interface MDao {
	public Movie getMovieDetails(int mid);
	public List<SeatInfo> getSeats(int scheduleId);
	public MovieSchedule getScheduleDetails(MovieSchedule ms);
	public List<Movie> getMovies();
	public int insertSchedule(MovieSchedule ms);
	public int insertBookingInfo(BookingDetails bd);
	public int insertSeatInfo(SeatInfo si);
	
}

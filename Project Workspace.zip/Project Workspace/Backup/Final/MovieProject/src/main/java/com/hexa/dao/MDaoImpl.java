package com.hexa.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hexa.entity.BookingDetails;
import com.hexa.entity.CustomerDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

/**
 * 
 * @author Abhinaya.S , kalpana . R
 * @version 1.0
 * <p> This class is used perform the CRUD operation on the database for the movie application </p>
 */

@Repository("daorepository")
public class MDaoImpl implements MDao {

	@Autowired
	private SessionFactory sfac;

	/**
	 * @param mid Movie Id
	 * @return returns Movie instance
	 * <p> This method returns the movie instance for a particular movie id </p>
	 */
	@Override
	public Movie getMovieDetails(int mid) {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie where movId = ?");
		qry.setInteger(0, mid);
		Movie movieDetails = (Movie) qry.uniqueResult();
		sess.close();
		return movieDetails;
	}

	/**
	 * @param scheduleId Schedule Id of a movie
	 * @return returns list of SeatInfo instance
	 * <p> This method returns the SeatInfo instance for a particular movie Schedule </p>
	 */
	@Override
	public List<SeatInfo> getSeats(int scheduleId) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from SeatInfo s inner join fetch  s.bookingDetails b where b.scheduledMovie.schId = ?  ");
		qry.setInteger(0, scheduleId);
		List<SeatInfo> s = qry.list();
		sess.close();
		return s;
	}

	/**
	 * @param ms MovieSchedule Instance
	 * @return returns MovieSchedule Instance
	 * <p> This method returns the MovieSchedule instance for a particular movie Schedule </p>
	 */
	@Override
	public MovieSchedule getScheduleDetails(MovieSchedule ms) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from MovieSchedule where movieScheduled.movId = ? and schShow = ? and  schDate = ?");
		qry.setInteger(0, ms.getMovieScheduled().getMovId());
		qry.setString(1, ms.getSchShow());
		qry.setDate(2, ms.getSchDate());
		MovieSchedule s = (MovieSchedule) qry.uniqueResult();
		sess.close();
		return s;
	}

	/**
	 * @return returns Movie Instance
	 * <p> This method returns the list of Movie instances </p>
	 */
	@Override
	public List<Movie> getMovies() {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie m");
		List<Movie> lst = qry.list();
		sess.close();
		return lst;
	}

	/**
	 * @param ms Movie Schedule Instance for the movie to insert
	 * @return returns Integer value
	 * <p> This method returns the database insertion result of Movie Schedule</p>
	 */
	@Override
	public int insertSchedule(MovieSchedule ms) {
		Session sess = sfac.getCurrentSession();
		sess.save(ms);
		return 1;
	}

	/**
	 * @param bd BookingDetails Instance for the movie booked
	 * @return returns Integer value
	 * <p> This method returns the database insertion result of Booking Details</p>
	 */
	@Override
	public int insertBookingInfo(BookingDetails bd) {
		Session sess = sfac.getCurrentSession();
		sess.save(bd);
		return 1;
	}

	/**
	 * @param si SeatInfo Instance for the movie booked
	 * @return returns Integer value
	 * <p> This method returns the database insertion result of Seat Information</p>
	 */
	@Override
	public int insertSeatInfo(SeatInfo si) {
		Session sess = sfac.getCurrentSession();
		sess.save(si);
		return 1;
	}

	/**
	 * @param ms Movie Schedule Instance for the movie schedule to be updated
	 * @return returns Integer value
	 * <p> This method returns the database updation result of Movie Scheduled</p>
	 */
	@Override
	public int updateSchedule(MovieSchedule ms) {
		Session sess = sfac.getCurrentSession();
		sess.update(ms);
		return 1;
	}

	/**
	 * @return returns maxBookId value
	 * <p> This method returns the maximum Booking Id in Database</p>
	 */
	@Override
	public int getBookingDetailsMaxId() {
		Session sess = sfac.openSession();
		int maxBookId = 0;
		String hql = "select max(bookId) from BookingDetails";
		Query qry = sess.createQuery(hql);	
		Object obj = qry.uniqueResult();
		if(obj != null) {
		maxBookId = (int)qry.uniqueResult();
		
		}
		return maxBookId;
	}

	/**
	 * @return returns CustomerDetails Instance
	 * <p> This method returns the customer Details of particular customer login</p>
	 */
	@Override
	public CustomerDetails getCustomerDetails(String email,String password) {
		Session sess = sfac.openSession();
		String hql = "from CustomerDetails where custEmail = ? and custPassword = ?";
		Query qry = sess.createQuery(hql);		
		qry.setString(0,email);
		qry.setString(1,password);
		CustomerDetails custDetails = (CustomerDetails)qry.uniqueResult();
		return custDetails;
	}
	
	/**
	 * @return returns list of BookingDetails Instance
	 * <p> This method returns the Booking Details of a particular customer</p>
	 */
	@Override
	public List<BookingDetails> getHistory(int cid) {
		Session sess = sfac.openSession();
		String hql = "from BookingDetails b inner join fetch b.custDetails c where c.custId=?";
		Query qry = sess.createQuery(hql);
		qry.setInteger(0, cid);
		List<BookingDetails> bookingHistory = qry.list();
		return bookingHistory;
	}

	

}
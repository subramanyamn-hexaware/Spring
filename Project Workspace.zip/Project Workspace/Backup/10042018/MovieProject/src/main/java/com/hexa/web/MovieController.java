package com.hexa.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hexa.dao.MDao;
import com.hexa.entity.CustomerDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.service.BookingService;

@Controller
public class MovieController {

	private Logger logger = LoggerFactory.getLogger("empapp");

	@Autowired
	private MDao dao;

	@Autowired
	private BookingService bService;

	@RequestMapping("/")
	public String displayHome() {
		return "Login";

	}

	@RequestMapping("/about")
	public String navigateToAbout() {
		return "About";
	}
	
	@RequestMapping("logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "Login";
	}
	
	@RequestMapping("viewMovies")
	public String viewAllMovies(Model model) {
		model.addAttribute("movies", dao.getMovies());
		logger.debug("movie size" + dao.getMovies().size());
		return "ViewAllMovies";
	}

	@RequestMapping(value="/view", method=RequestMethod.POST)
	public String loginNavigate(@RequestParam("emailId") String custEmail,@RequestParam("password") String password, HttpServletRequest request, Model model)
			throws IOException {
		logger.debug("Inside LoginNavigation Method");
		CustomerDetails custDetails = dao.getCustomerDetails(custEmail,password);

		if (custDetails != null) {
			request.getSession().setAttribute("custDetails", custDetails);
			model.addAttribute("movies", dao.getMovies());
			logger.debug("movie size" + dao.getMovies().size());
			return "ViewAllMovies";
		}
		return "Login";

	}

	@RequestMapping("viewimg")
	public String viewImage(@RequestParam("imgname") String img, HttpServletResponse resp) throws IOException {
		resp.setContentType("image/jpeg");
		FileInputStream fis = new FileInputStream("d:\\photos\\" + img);
		byte[] arr = new byte[fis.available()];
		fis.read(arr);

		ServletOutputStream out = resp.getOutputStream();
		out.write(arr);
		fis.close();
		return null;

	}

	@RequestMapping("/viewall")
	public String viewAllMovies(HttpServletRequest request, Model model) throws IOException {
		logger.debug("inside vuiewall  method");
		model.addAttribute("movies", dao.getMovies());
		logger.debug("movie size" + dao.getMovies().size());
		return "ViewAllMovies";
	}

	@RequestMapping("/viewMovie")
	public String viewMovie(@RequestParam("movid") int movieId, HttpServletRequest request, Model model)
			throws IOException {
		Movie movie = dao.getMovieDetails(movieId);
		Set<Date> schDates = new HashSet<Date>();
		Set<MovieSchedule> ms = movie.getMoviesScheduled();
		for (MovieSchedule movieSchedule : ms) {
			schDates.add(movieSchedule.getSchDate());
		}
		request.getSession().setAttribute("movdet", dao.getMovieDetails(movieId));
		request.getSession().setAttribute("movSchDates", schDates);
		request.getSession().setAttribute("useatslist", new HashMap<Integer, Integer>());
		return "ViewMovieDetail";
	}

	@RequestMapping("/viewSeats")
	public String viewAllSeats(@RequestParam("date") String date, @RequestParam("show") String show,
			HttpServletRequest request, Model model) throws IOException, ParseException {
		MovieSchedule ms = new MovieSchedule();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		ms.setSchShow(show);
		ms.setSchDate(sdf.parse(date));
		ms.setMovieScheduled((Movie) request.getSession().getAttribute("movdet"));
		request.getSession().setAttribute("movieScheduled", ms);
		request.getSession().setAttribute("userseats", bService.getBookedSeatsInfo(ms));
		return "ViewSeatInfo";
	}

	@RequestMapping("/addSeats")
	public String addSeat(@RequestParam("sno") int seatNum, Model model, HttpServletRequest request)
			throws IOException, ParseException {
		Map<Integer, Integer> seatsSelectedLst = (Map<Integer, Integer>) request.getSession()
				.getAttribute("useatslist");
		if (seatsSelectedLst.containsKey(seatNum)) {
			seatsSelectedLst.remove(seatNum);
		} else {
			seatsSelectedLst.put(seatNum, seatNum);
		}

		double price = seatsSelectedLst.size() * 120;
		model.addAttribute("tctprice", price);
		return "ViewSeatInfo";
	}

	@RequestMapping("/confirmBooking")
	public String insertBookingDetails(Model model, HttpServletRequest request) throws IOException, ParseException {
		CustomerDetails cs = (CustomerDetails) request.getSession().getAttribute("custDetails");
		MovieSchedule ms = (MovieSchedule) request.getSession().getAttribute("movieScheduled");
		Map<Integer, Integer> seatsSelectedLst = (Map<Integer, Integer>) request.getSession()
				.getAttribute("useatslist");
		int bookingResult = bService.bookTckt(cs, ms, seatsSelectedLst);
		logger.info("Booking Result : " + bookingResult);
		model.addAttribute("bookingStatus", bookingResult);
		return "BookingConfirmation";
	}

}

package com.hexa.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.hexa.dao.MDao;
import com.hexa.dao.MDaoImpl;
import com.hexa.entity.BookingDetails;
import com.hexa.entity.CustomerDetails;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;


@Service("myser")
public class BookingServiceImpl implements BookingService{
	
	

	@Autowired
	private MDao dao;
	
	private int bookId;
	
	@Override
	public List<Integer> getBookedSeatsInfo(MovieSchedule ms) {
		int scheduleId;
		List<SeatInfo> seatDetails;
		List<Integer> seats = new ArrayList<>();
		MovieSchedule scheduleDetails =  dao.getScheduleDetails(ms);
		if(scheduleDetails != null) {
			scheduleId = scheduleDetails.getSchId();
			seatDetails = dao.getSeats(scheduleId);
			for(SeatInfo sinfo : seatDetails) {
				seats.add(sinfo.getSeatNo());
			}
		}
		return seats;
	}
	public int updateSchedule(MovieSchedule ms, int seats) {
		MovieSchedule ms1 = dao.getScheduleDetails(ms);
		System.out.println("After Obtain schedule Details");
		if (ms1 != null) {
			int totalSeats = ms1.getSchSeats();
			System.out.println("Total Seats" + totalSeats);
			ms1.setSchSeats(totalSeats - seats);
			System.out.println("Set Seats" + ms1.getSchSeats());
			int res = dao.updateSchedule(ms1);
			if (res > 0) {
				return 1;
			}			
		}

		return 0;
	}
	
	

	@Override
	public int insertBookingInfo(CustomerDetails cs, MovieSchedule ms, int tickets) {
		MovieSchedule ms1 = dao.getScheduleDetails(ms);
		ms1.getSchId();
		ms1.getMovieScheduled().getMovId();

		BookingDetails bd = new BookingDetails();
		bookId = dao.getBookingDetailsMaxId() + 1;
		
		int cost = tickets * 120;
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		bd.setBookId(bookId);
		bd.setCustDetails(cs);
		bd.setNoOfTckts(tickets);
		bd.setBookDate(date);
		bd.setScheduledMovie(ms1);
		bd.setTotalPrice(cost);
		bd.setMovieBooked(ms1.getMovieScheduled());
		dao.insertBookingInfo(bd);
		return 1;
	}
	
	
	
	@Transactional(readOnly = false)
	@Override
	public int bookTckt(CustomerDetails cs,MovieSchedule ms , Map<Integer,Integer> seats) {
		int scheduleUpdRes = updateSchedule(ms, seats.size());
		if(scheduleUpdRes == 1) {
			int insBookTabRes = insertBookingInfo(cs, ms, seats.size());
			if(insBookTabRes == 1) {
				BookingDetails bd = new BookingDetails();
				SeatInfo sf ;
				bd.setBookId(bookId);
				for(Integer seatLst : seats.values()) {
					sf = new SeatInfo();
					sf.setSeatNo(seatLst);
					sf.setBookingDetails(bd);
					dao.insertSeatInfo(sf);
				}
			}
			return 1;
		}
		return 0;
	}
}

package com.hexa.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hexa.entity.BookingDetails;
import com.hexa.entity.CustomerDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

@Repository("daorepository")
public class MDaoImpl implements MDao {

	@Autowired
	private SessionFactory sfac;

	@Override
	public Movie getMovieDetails(int mid) {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie where movId = ?");
		qry.setInteger(0, mid);
		Movie movieDetails = (Movie) qry.uniqueResult();
		sess.close();
		return movieDetails;
	}

	@Override
	public List<SeatInfo> getSeats(int scheduleId) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from SeatInfo s inner join fetch  s.bookingDetails b where b.scheduledMovie.schId = ?  ");
		qry.setInteger(0, scheduleId);
		List<SeatInfo> s = qry.list();
		sess.close();
		return s;
	}

	@Override
	public MovieSchedule getScheduleDetails(MovieSchedule ms) {
		Session sess = sfac.openSession();
		Query qry = sess
				.createQuery("from MovieSchedule where movieScheduled.movId = ? and schShow = ? and  schDate = ?");
		qry.setInteger(0, ms.getMovieScheduled().getMovId());
		qry.setString(1, ms.getSchShow());
		qry.setDate(2, ms.getSchDate());
		MovieSchedule s = (MovieSchedule) qry.uniqueResult();
		sess.close();
		return s;
	}

	@Override
	public List<Movie> getMovies() {
		Session sess = sfac.openSession();
		Query qry = sess.createQuery("from Movie m");
		List<Movie> lst = qry.list();
		sess.close();
		return lst;
	}

	@Override
	public int insertSchedule(MovieSchedule ms) {
		Session sess = sfac.getCurrentSession();
		sess.save(ms);
		return 1;
	}

	@Override
	public int insertBookingInfo(BookingDetails bd) {
		Session sess = sfac.getCurrentSession();
		sess.save(bd);
		return 1;
	}

	@Override
	public int insertSeatInfo(SeatInfo si) {
		Session sess = sfac.getCurrentSession();
		sess.save(si);
		return 1;
	}

	@Override
	public int updateSchedule(MovieSchedule ms) {
//		Session sess = sfac.openSession();
//		Transaction tx = sess.beginTransaction();
//		sess.update(ms);
//		tx.commit();
//		return 1;
		
		Session sess = sfac.getCurrentSession();
		sess.update(ms);
		return 1;
	}

	@Override
	public int getBookingDetailsMaxId() {
		Session sess = sfac.openSession();
		String hql = "select max(bookId) from BookingDetails";
		Query qry = sess.createQuery(hql);		
		int maxBookId = (int)qry.uniqueResult();
		return maxBookId;
	}

	@Override
	public CustomerDetails getCustomerDetails(String email) {
		Session sess = sfac.openSession();
		String hql = "from CustomerDetails where custEmail = ?";
		Query qry = sess.createQuery(hql);		
		qry.setString(0,email);
		CustomerDetails custDetails = (CustomerDetails)qry.uniqueResult();
		return custDetails;
	}

}

package com.hexa;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.hexa.entity.CustomerDetails;
import com.hexa.entity.Movie;
import com.hexa.entity.MovieSchedule;
import com.hexa.service.BookingService;

@SpringBootApplication
@EnableTransactionManagement
@EntityScan("com.hexa.entity")
public class MovieProjectApplication implements CommandLineRunner{

	
	
	@Autowired
	private EntityManagerFactory emf;
	

//	@Autowired
//	private MDao dao;
	
	@Autowired
	private BookingService bs;
	
	@Bean
	public SessionFactory getSessioNFactory() {
		return emf.unwrap(SessionFactory.class);
	}	
	
	@Bean
	@Autowired
	public HibernateTransactionManager getTxmanger(SessionFactory sfac){
		HibernateTransactionManager tx = new HibernateTransactionManager();
		tx.setSessionFactory(sfac);
		return tx;
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(MovieProjectApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("All Students");
//		List<Integer> ls = new ArrayList<>();
//		ls.add(22);
//		ls.add(23);
//		CustomerDetails cd = new CustomerDetails();
//		cd.setCustId(1);
//		 String sDate1="2018-04-05";  
//		    Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(sDate1); 
//		MovieSchedule ms = new MovieSchedule();
//		Movie mv = new Movie();
//		mv.setMovId(2);
//		ms.setMovieScheduled(mv);
//		ms.setSchDate(date1);
//		ms.setSchShow("MATNEE");
//		int insertionResult = bs.bookTckt(cd, ms, ls);
//		if(insertionResult > 0) {
//			System.out.println("Inserted");
//		}

		
	}
}

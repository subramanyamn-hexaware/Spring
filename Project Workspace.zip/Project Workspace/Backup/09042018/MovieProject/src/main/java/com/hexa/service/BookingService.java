package com.hexa.service;

import java.util.List;
import java.util.Map;

import com.hexa.entity.CustomerDetails;
import com.hexa.entity.MovieSchedule;
import com.hexa.entity.SeatInfo;

public interface BookingService {
	public List<Integer> getBookedSeatsInfo(MovieSchedule ms);
	public int updateSchedule( MovieSchedule ms,int seats);
	public int insertBookingInfo(CustomerDetails cs, MovieSchedule ms, int tickets);
	int bookTckt(CustomerDetails cs, MovieSchedule ms,  Map<Integer,Integer> seats);
}

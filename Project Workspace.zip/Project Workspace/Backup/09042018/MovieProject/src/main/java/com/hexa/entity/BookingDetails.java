package com.hexa.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "BOOKING_DETAILS")
public class BookingDetails {

	@Id
	@Column(name = "BOOK_ID")
	private int bookId;

	@Column(name = "NO_OF_TCKTS")
	private int noOfTckts;

	@Column(name = "TOTAL_PRICE")
	private double totalPrice;

	@Column(name = "BOOK_DATE")
	private Date bookDate;

	@ManyToOne
	@JoinColumn(name = "CID", referencedColumnName = "CUST_ID")
	private CustomerDetails custDetails;

	@OneToMany(mappedBy = "bookingDetails")
	private Set<SeatInfo> seatList;

	@ManyToOne
	@JoinColumn(name = "MID", referencedColumnName = "MOV_ID")
	private Movie movieBooked;

	@ManyToOne
	@JoinColumn(name = "SID", referencedColumnName = "SCH_ID")
	private MovieSchedule scheduledMovie;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getNoOfTckts() {
		return noOfTckts;
	}

	public void setNoOfTckts(int noOfTckts) {
		this.noOfTckts = noOfTckts;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Date getBookDate() {
		return bookDate;
	}

	public void setBookDate(Date bookDate) {
		this.bookDate = bookDate;
	}

	public CustomerDetails getCustDetails() {
		return custDetails;
	}

	public void setCustDetails(CustomerDetails custDetails) {
		this.custDetails = custDetails;
	}

	public Set<SeatInfo> getSeatList() {
		return seatList;
	}

	public void setSeatList(Set<SeatInfo> seatList) {
		this.seatList = seatList;
	}

	public Movie getMovieBooked() {
		return movieBooked;
	}

	public void setMovieBooked(Movie movieBooked) {
		this.movieBooked = movieBooked;
	}

	public MovieSchedule getScheduledMovie() {
		return scheduledMovie;
	}

	public void setScheduledMovie(MovieSchedule scheduledMovie) {
		this.scheduledMovie = scheduledMovie;
	}

}

package com.hexa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SEAT_INFO")
public class SeatInfo {

	@Id
	@Column(name = "S_NO", insertable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sNo;

	@Column(name = "SEAT_NO")
	private int seatNo;

	@ManyToOne
	@JoinColumn(name = "BID", referencedColumnName = "BOOK_ID")
	private BookingDetails bookingDetails;

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}

	public void setBookingDetails(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

}
